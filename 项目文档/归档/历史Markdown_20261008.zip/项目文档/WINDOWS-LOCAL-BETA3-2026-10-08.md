# Windows v2.3beta.3 本地测试包（2026-10-08）

用户授权修复当前已发现问题后打包beta3。本轮已完成源码修复、统一交付门禁及本地安装器生成，**没有提交、推送、上传或公开发布**。真实校园网认证和长期稳定性仍待现场验收。

后续接续：本页保留首次beta3包的原始目录/摘要。其19:11新日志已越过门户，但旧UA导致初始化空响应；后续已修正64位通道，独立修复包及验证见[UA2104修复记录](WINDOWS-BOOTSTRAP-UA-FIX-2026-10-08.md)，本页历史安装器不覆盖。

## 最终交付

```text
ESurfingDialer-Windows-Client/00_最终安装包/Windows客户端_v2.3beta.3/
  ESurfingDialer-Windows-v2.3beta.3-Setup.exe
  README_TEST.txt
  SHA256SUMS.txt
  BUILD-MANIFEST.json
  PUBLISHED-FILES.json
  SOURCE-FILES.json
  SOURCE-INPUTS.zip
  本地验证结果/
```

| 项目 | 最终结果 |
| --- | --- |
| 安装器大小 | 157783762字节，约157.78MB |
| 安装器SHA256 | `3982976f9814128f7a58a6d040a1723d1e3f954a67565b57f5555026658782a0` |
| 客户端 / 文件版本 | `2.3beta.3` / `2.3.0.3`，EXE、DLL、安装器一致 |
| 发布文件 | 885个，共315358804字节 |
| 运行时 | Windows x64，自包含.NET/WPF 10.0.12、Temurin Java 21.0.11 |
| 核心版本 / SHA256 | Gradle仍为1.4.0；`e47daddb76e1461e70c319b92ba2c9b177730877d02096a22a59908ddd4e2467` |
| 原生资源SHA256 | `656ace25d47cc453685cc4109b5f4578d466b219d759008ac5720244ee899722`，与Windows源码一致 |

发布文件在源码工程 `dist/v2.3beta.3-release/ESurfingDialerLite`。只交付上表最终目录；其他dist/artifacts候选保留用于追溯。

## 纳入的修复

- 保留beta2的八项运行修复、六项离线修复及实际程序入口修复。
- 纳入[10-08门户修复](WINDOWS-PORTAL-FIX-2026-10-08.md)：兼容闭合引号属性中的裸查询分隔符，全部auth先校验、再接受唯一规范化地址；坏成员/冲突auth/重复ticket仍拒绝。XML错误增加安全阶段、位置和固定类别；Windows原生库、UA、算法和恢复策略保持。
- 修复启动检查误通过：InputIdle=false即失败，要求本次PID的WPF主窗口标题/类匹配且限时响应；观察后再次核对。进程树退出、句柄释放及配置二次检查完成后才记录通过。
- 新增 `scripts/Build-LocalBeta.ps1`：组合核心回归、包内发布副本回归、实际EXE就绪/清理、版本与来源摘要、必需门户类、原生库、包内.NET成功加载、文档和旧文件保护。拒绝已有输出，失败非零且不生成通过记录，缺依赖不能当成功。

## 实际验证

| 验证 | 结果 |
| --- | --- |
| 离线核心构建/回归 | 319项认证、63项恢复通过 |
| 发布DLL/JRE/JAR/.NET隔离副本，`--core --stress` | 188项通过，使用合成账户及本机替身 |
| 启动门禁自身回归 | 13项通过，覆盖未就绪、kill/退出/Dispose失败 |
| 最终实际EXE入口 | InputIdle、WPF窗口响应、空配置不变和清理通过；测试PID已退出 |
| 产品.NET宿主 | 精确的 `Loaded library from` trace确认加载包内coreclr.dll |
| 最终包内Java/JAR门户重放 | 10组符合预期；旧失败属性/等值auth/组合通过，冲突、坏路径、重复ticket、未知实体及DTD仍拒绝 |
| 独立交付复核 | 全部校验条目、885个发布文件及总字节数、103项源码输入/归档、JAR CRC/原生资源通过 |
| 文件保护 | 门禁71份Docker/历史交付文件保持；此前快照另核对66项非本轮授权修改的既有内容与删除保持 |
| 失败路径 | 已有输出、缺少JDK及保留的StartupUri故障EXE均被非零拒绝，未误写通过 |

短时压力包含30次预热、200次启停/40次恢复、2000条界面事件、200次配置提交，约27.62秒。测试进程句柄876→873、GC后托管堆4719920→4636368字节；不是实际登录后的产品长期资源测量。部分回归夹具仍通过PATH的dotnet启动，产品EXE的包内运行时加载另以宿主trace核对。

最终入口退出0；验证目录为Windows源码下 `artifacts/local-beta3-release-20261008`，独立复核工具与失败路径证据在 `artifacts/local-beta3-preflight-20261008`。构建前后源码输入一致；103项包含未跟踪的门户helper/回归和两个启动脚本，归档逐项摘要匹配。分支 `codex/windows-auth-review-20261008`，HEAD为db6157f6d0c3d3b199a920070b5d6b47147c8dbe，修复来自未提交工作区；不能仅凭DLL的Git后缀判断是否包含修复。

交付后仅为核心README接续beta3状态，源码归档仍保留实际构建时的文档快照；其构建摘要与接续后摘要在清单 `PostBuildDocumentation` 中分别保存。运行源码和构建脚本没有后续变化，安装器摘要保持；此纯文档接续不重跑产品回归。

首候选因Inno Setup固定宽度PE文本版本填充被门禁拒绝，已按实际资源去除尾部填充后比较。次候选通过运行验证，但独立核对发现清单总字节数字段为空，改为Int64累加后完整重跑；次候选完整保存在 `artifacts/local-beta3-final-20261008/manifest-candidate`。最终摘要仅以上表为准。

## 使用与验收边界

先从窗口或托盘完全退出旧客户端，再运行最终目录的安装器。AppId和账户存储位置保持原有约定；升级前可自行备份 `%LOCALAPPDATA%\ESurfingDialerLite`，备份包含加密账户信息，应妥善保管。打开后确认版本beta3，再测试校园网连接；失败时从设置导出日志，保留版本、时间和新XML/认证阶段信息。

本轮没有安装到真实程序目录，没有改真实账户或系统自启。安装器编译、发布文件和EXE入口通过，**实际安装/升级/卸载及安装器提取尚未验收**；当前没有现成兼容提取器，不把指定另一安装目录当作无副作用解包。

旧beta2五次失败的具体XML坏字符/setup仍未由旧日志直接证实。本次修复已受控复现的兼容缺口并补足诊断；历史原生 `load()=0`、真实会话/ticket/登录/确认心跳、实际断网/切网/休眠和长期稳定性继续按[统一待办](PENDING-OPTIMIZATIONS.md)验收，不能把替身成功当作校园网已恢复。

## 重建

在Windows源码目录使用PowerShell 7、现有Inno Setup 6和.NET/JDK/Gradle缓存执行，每次选择新目录：

```powershell
$betaRun = Get-Date -Format 'yyyyMMdd-HHmmss'
pwsh -NoProfile -File ./scripts/Build-LocalBeta.ps1 -Offline `
  -OutputRoot "$PWD/dist/v2.3beta.3-$betaRun" `
  -ValidationDirectory "$PWD/artifacts/beta3-$betaRun" `
  -DeliveryDirectory "$PWD/../../00_最终安装包/Windows客户端_v2.3beta.3-$betaRun"
```
