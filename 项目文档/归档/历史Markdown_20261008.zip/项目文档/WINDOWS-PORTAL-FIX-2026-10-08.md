# Windows 门户兼容与 XML 诊断修复（2026-10-08）

关联：WOPT-01、W2-ATTR、W2-AUTH-DUP；历史原生初始化问题继续沿用 AUTH-INIT。用户提供的 v2.3beta.2 日志在两次启动中五次报 `PORTAL_CONFIG_XML_INVALID`，未进入 bootstrap 或原生会话，证据见[重新核查](WINDOWS-AUTH-RECHECK-2026-10-08.md)。

**本记录结束时源码修复、核心 JAR 构建和离线回归已完成，旧 v2.3beta.2 安装包没有更新。** 后续授权已将修复纳入[本地v2.3beta.3包](WINDOWS-LOCAL-BETA3-2026-10-08.md)，旧包仍保留原状。未进行校园网认证，不能据此宣称实际登录恢复；本次现场 XML 的具体坏字符仍未由旧日志直接证实。下文“未打安装包”描述保留为源码阶段的历史边界。

## 修复行为

1. 将既有 `&key=value` 查询串兼容扩展到闭合单/双引号属性，保留实体、CDATA、注释和处理指令；处理指令按完整 `?>` 边界保留。未闭合引号、裸 `<`、未知实体及其他坏 XML 继续拒绝。
2. 对所有 `auth-url` 逐项检查非空、文本结构、安全 URL 和 `/auth.cgi` 路径，再按实际规范化 HttpUrl 去重。只有唯一请求地址才接受；任一坏项或地址冲突均拒绝，不过滤坏项或选择第一项。`ticket-url` 仍要求唯一。
3. 分离 XML 解析器初始化与内容解析的错误类别。保留安全配置、大小/深度、IP 与 URL 校验，新增日志字段 `configChars`、`xmlStage`、`xmlLine`、`xmlColumn`、`xmlIssue`、`xmlContext`。

| 错误码 | 含义 |
| --- | --- |
| `PORTAL_XML_PARSER_SETUP_FAILED` | 解析器工厂选择、安全配置或创建失败，`xmlStage=PARSER_SETUP` |
| `PORTAL_CONFIG_XML_INVALID` | XML 语法或安全规则拒绝，`xmlStage=XML_PARSE`；存在位置时只输出数字与固定类别 |
| `PORTAL_XML_PARSER_FAILED` | XML 解析阶段的其他异常，`xmlStage=XML_PARSE` |

位置指向规范化、包装后的 XML 输入，不是原 HTML 的位置；上下文是解析器报告位置的词法类别，不承诺就是最初错误位置。异常消息只在内存映射为固定枚举，不保存或输出页面、属性值、URL、原始异常消息和因果栈。新增字段通过现有 `Client` 失败日志输出，健康 JSON 仍仅保存原有错误码等状态。

Windows UA、ARM64 原生库、JNI、算法、bootstrap 请求、设备身份、legacy 入口、重试/暂停及恢复策略均未修改。此次只借鉴 Docker 已经现场验证的门户规则，不跨产品替换认证通道。

## 验证结果

Windows 源码目录：`ESurfingDialer-Windows-Client/01_客户端源码/ESurfingDialer-Windows-Client`。

| 验证 | 实际结果 |
| --- | --- |
| JDK17 启动 Gradle8.4、JDK21 编译/执行，`Build-Core.ps1 -Offline -Regression` | 构建成功，319 项认证、63 项恢复通过；首次完整运行48秒 |
| 审查后最终认证回归 | 319 项再次通过，23秒；只调整测试未知请求失败分支，生产代码未变 |
| WPF 编译 | 0 警告、0 错误 |
| `ClientRegression --core`，使用本轮生成 JAR 与独立数据目录 | 182 项通过，包含真实 Java 子进程启动/控制、恢复、暂停/停止边界 |
| 直接使用新 JAR 与旧包内 Java21 重放10组合成门户 | 原失败的属性/重复/组合输入全部通过；冲突 auth、坏路径、重复 ticket、未知实体及 DTD 继续拒绝 |
| JAR 内容和保护检查 | 12 个门户类与编译输出逐字节一致，无回归类打入 JAR；客户端回归的 JAR 摘要匹配；72份受保护文件存在状态/摘要未变 |

新增兼容、XML 与客户端流程回归共152项，原167项认证检查保留。真实 `Client.runClientIteration()` 在 bootstrap/原生/传输替身下完成 `bootstrap → session → ticket → login → confirm`，出现 `LOGIN_CONFIRMED` 和 `LOGIN_SUCCESS`；坏 XML 与冲突 auth 不调用 bootstrap、native 或账号提交。它证明门户阻断在合成输入下解除，不是实际算法或学校认证通过。

诊断回归覆盖工厂不可用、安全 XML 拒绝、中英文错误模板、LF/CRLF 位置、HTTP/缓存元数据合并及无敏感内容泄露。HTTP 诊断使用拦截器合成响应，原有传输/恢复回归使用本机 HTTP；未使用真实账号、外部门户或原生库执行认证。独立审查发现合成未知请求若抛普通异常，可能触发客户端真实探测回退；已改为确定性夹具失败并重新执行认证回归。

构建命令：

```powershell
./scripts/Build-Core.ps1 -Offline -Regression -Jdk17 'D:/Java/JDK17' -Jdk21 'D:/Java/JDK21'
dotnet build ./app/ESurfingDialerLite/ESurfingDialerLite.csproj --no-restore
# 子进程回归使用 Java21，数据和输出均在本轮独立 artifacts 目录。
$env:JAVA_HOME = 'D:/Java/JDK21'
dotnet run --project ./tests/ClientRegression/ClientRegression.csproj --no-restore -- artifacts/portal-fix-20261008/client --core
```

本地验证日志、合成输出、`verify_fix.py`、`VERIFICATION.json` 与保护快照在忽略目录 `artifacts/portal-fix-20261008`。客户端回归 `result.json` 为通过，测试进程按回归框架清理。

## 当前构建与交付边界

- 新核心：`core/ESurfingDialerCore/build/libs/ESurfingDialer-1.4.0-all.jar`。
- SHA256：`e47daddb76e1461e70c319b92ba2c9b177730877d02096a22a59908ddd4e2467`。
- 原生资源仍为 `656ace25d47cc453685cc4109b5f4578d466b219d759008ac5720244ee899722`。
- 核心 Gradle 版本仍为1.4.0，不表示 Windows 新安装包版本；已交付 v2.3beta.2 的 JAR 仍是 `45607a20...4c6a99`，不会因本轮源码变化自动更新。
- 本轮没有生成安装包、修改已安装客户端、提交、推送或发布；Docker源码、原生资源、其他既有改动与历史Windows包保持。

下一步是按后续交付授权把修复纳入新测试包，现场确认门户通过，再观察会话、票据、登录及首次心跳。若仍失败，新日志能区分 setup、XML语法、字段校验和后续原生阶段。旧 AUTH-INIT 的 `load()=0` 以及恢复/长期稳定验收仍独立保留，当前剩余工作只在[统一待办](PENDING-OPTIMIZATIONS.md)维护。
