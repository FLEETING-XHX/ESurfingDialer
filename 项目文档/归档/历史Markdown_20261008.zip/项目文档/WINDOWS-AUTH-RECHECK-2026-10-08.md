# Windows v2.3beta.2 认证失败重新核查（2026-10-08）

关联：WOPT-01、AUTH-INIT、W2。用户确认当前无法使用的是本地 v2.3beta.2；首次核查后补充 `ESurfingDialer-logs-20261008-161408.zip`，新证据接续在下节。

## 结论与证据边界

**v2.3beta.2 实际包内核心仍有 Docker beta3 此次已修复的两个门户兼容阻断点，已用相同合成输入复现。** 属性内查询串裸 `&` 和嵌套重复的相同 `auth-url` 分别导致拒绝，组合出现时先报 XML 错误；Docker 已交付 beta3 对这些输入均通过。两边使用同一个 Java 21 时结果不变。

这证明 Windows 对该门户形态不兼容。**随后收到的新日志已确认当前失败位于门户 XML 配置处理，尚不能确定具体语法，也不能解释所有历史故障。** Windows 与 Docker 的 UA、设备和网络入口不同，收到的页面未必相同。09-23 的 v2.1/v2.2 已进入原生 `load()` 后返回零，发生在门户解析之后，必须继续作为独立的 AUTH-INIT 未决问题。

本轮只做核查、无网络复现和文档更新，没有修改运行源码或现有包，没有登录账号、启动客户端/容器、提交或推送。

后续实施：用户随后明确要求开始修复，已完成[门户兼容与XML诊断源码修复](WINDOWS-PORTAL-FIX-2026-10-08.md)，319项认证、63项恢复、182项客户端检查通过，新JAR旧失败合成输入通过。本文下方“尚未修复/本轮仅核查”保留最初核查时的状态；当前源码已修、历史安装包未更新，真实认证仍待现场。

## 新日志：当前阻断已定位（16:13–16:14）

ZIP 中有 `client.log`、`core.log`、`health.json`、脱敏 `settings.json`。`ClientVersion=2.3.0.2` 与 v2.3beta.2 文件版本一致；仅凭版本和日志行号不能核验用户实际安装 JAR 的字节摘要。

| 日志时间（2026-10-08） | 错误码 | 重试状态 | HTML 正文字节数 |
| --- | --- | --- | --- |
| 16:13:31 | `PORTAL_CONFIG_XML_INVALID` | backoff | 27229 |
| 16:13:37 | 同上 | backoff | 27273 |
| 16:13:47 | 同上 | paused | 27236 |
| 16:14:00（重新启动后） | 同上 | backoff | 27222 |
| 16:14:05 | 同上 | backoff | 27264 |

五次都为 `httpStatus=200 hop=2 mediaType=HTML blocks=1 cachedConfig=false`，页面约27KiB，低于128KiB限制。可以确认获取到了含配置标记的页面，失败类别不是响应超限或配置截断。`authFields=-1 ticketFields=-1` 表示 DOM 成功前尚未统计，不能解释成字段缺失或重复。

两次启动共出现五次 `LOGIN_ATTEMPT`，但没有 `AUTH_ENDPOINTS`、`TICKET_RESPONSE`、`TICKET_BODY`、`ZSM_METADATA`、`SESSION_READY`、`TICKET_READY`、`LOGIN_CONFIRMED` 或 `LOGIN_SUCCESS`。结合实际代码顺序，**这五次没有进入 bootstrap、原生会话初始化或账号密码提交，当前失败不是旧 `load()=0` 的同阶段复现**。不能因此保证越过门户后这些环节必定成功。

健康快照为 `authenticated=false`，登录/心跳成功时间均为0，`authenticationFailure=PORTAL_CONFIG_XML_INVALID`；client/network线程为存活。快照 `authenticationBlocked=false` 属于重新启动后的第二会话，不与首会话第三次已暂停矛盾。停止重开重置了计数，但输入兼容问题仍在。

**本日志没有精确 XML 位置或语法类别。** 旧实现也会把解析器初始化/安全设置失败归为同一码，不能仅凭此包排除 parser setup，或宣称已直接证实属性裸 `&`。结合 Docker 的现场定位及本轮 Windows 包内复现，属性兼容是有依据的优先排查项；重复等值 auth 是可能在 XML 通过后出现的第二个已知阻断，当前日志尚未走到该校验。安全阶段诊断仍应与兼容修复一并补齐。

原 ZIP 未复制到仓库、未解压或执行。只保存固定错误码、时间、计数、版本和安全健康字段到忽略目录 `artifacts/auth-review-20261008/new-log-evidence.json`，不保存设备身份、原始配置、完整URL或账号信息。

## 实际构建对照

| 对象 | 来源与 SHA256 |
| --- | --- |
| Windows 核心 | `dist/v2.3beta.2/ESurfingDialerLite/core/client.jar`，43424371 字节；`45607a20cdc79d08ade64abb9090fe28987102bfeb06c8dc53fb5259fb4c6a99` |
| Docker 核心 | `build/libs/ESurfingDialer-1.4.0-beta.3-all.jar`；`a05de2562492fcf6eda26279630b2f2a89a52734a92c1dfc903b6ef9f6e993f4` |

Windows JAR 与 v2.3beta.2 的 `PUBLISHED-FILES.json` 中 `core/client.jar` 的大小和摘要一致；Docker JAR 摘要与 [10-08 已交付门户修复包](DOCKER-LOCAL-BETA3-PORTAL-2026-10-08.md)一致。两份 JAR 的门户主类分别与现有编译输出逐字节一致。没有取得用户实际安装目录的 JAR 摘要，本轮核对的是本机对应交付目录。

使用包内 Java 21.0.11 运行 Windows JAR、JDK 17.0.19 运行 Docker JAR，再使用同一个包内 Java 21 运行 Docker JAR作为控制。工具只调用实际 `PortalConfiguration.parse()`，输入为 `.test` 域名和合成 IP，不发 HTTP、不加载原生会话、不读账户配置。

| 合成输入 | Windows v2.3beta.2 | Docker beta3（两种 Java 一致） |
| --- | --- | --- |
| 单 auth / 单 ticket、CDATA 正常配置 | 通过 | 通过 |
| 仅属性中含 `&b=2` | `PORTAL_CONFIG_XML_INVALID` | 通过 |
| 仅根下及深层出现相同 auth | `PORTAL_AUTH_URL_DUPLICATE` | 通过 |
| 上述两种形态组合 | `PORTAL_CONFIG_XML_INVALID` | 通过 |
| 两个不同 auth 地址 | 拒绝 | 拒绝 |
| 合法 auth 加错误路径 auth | 拒绝重复字段 | 拒绝错误路径 |
| 重复 ticket | 拒绝 | 拒绝 |
| 未知实体 / DTD | 各自拒绝 | 各自拒绝 |
| 仅元素正文含裸查询分隔符 | 通过 | 通过 |

10 组输入 × 3 次运行共核对 30 个预期结果。另外对包内重试策略验证，同一确定性门户错误连续三次的暂停序列为 `false,false,true`。这属于策略验证，不是三次真实联网登录。

可复现工具、输出和 `VERIFICATION.json` 位于 Windows 工程忽略目录 `artifacts/auth-review-20261008`。验证入口为 `py artifacts/auth-review-20261008/verify_comparison.py`；需要先按该目录记录生成三份 TSV。没有重新打包或重新构建产品核心。

## 已确认代码原因与旧回归遗漏

Windows 核心路径：`ESurfingDialer-Windows-Client/01_客户端源码/ESurfingDialer-Windows-Client/core/ESurfingDialerCore/src`。

1. **W2-ATTR：属性内查询分隔符未处理。** `main/kotlin/com/rsplwe/esurfing/PortalConfiguration.kt:120–141` 跳过整个标签，只对标签外正文执行有限转义。即使问题属性与 auth/ticket 无关，也会使整段 XML 解析失败。Docker 已将已有兼容扩展至闭合引号属性；不需要改算法。
2. **W2-AUTH-DUP：把等值重复地址当成冲突。** 同文件 `:53–65` 对全树 `auth-url` 要求数量严格为一；根下与深层的两个同值节点也拒绝。Docker 的修复是先校验每一项，再按实际规范化 HttpUrl 去重，仅接受唯一地址；不是直接取第一个。
3. **诊断粒度不足。** 同文件 `:90–115` 把解析器设置、创建和 XML 内容错误归为同一个错误码，没有 Docker 后来补充的安全位置、语法类别和属性上下文。初探 `utils/NetworkConnectivity.kt:120–122` 还将具体错误压成 `PORTAL_CONFIG_INVALID`，后续可能先出现笼统的缺 IP 日志。

旧 `test/kotlin/com/rsplwe/esurfing/PortalRegression.kt:48` 的属性样本没有裸 `&`；`:51–52` 只测正文查询串；`:62` 明确要求两个完全相同 auth 必须报重复。因此旧检查通过验证了旧规则，没有覆盖现场合法兼容形态。此前修复恢复、进程、状态和入口能改善其他问题，但没有改变这两个条件。

## 原生失败重新核对

Windows 当前仍使用 `CCTP/android64_vpn/2085`、ARM64 模拟器/API 23；Docker 使用 `CCTP/Android8_vpn/2082`、ARM32/API 19及配套 `ipv4` Hook。包内原生资源与各自源码一致：

| 资源 | Windows | Docker |
| --- | --- | --- |
| ELF / 大小 | AArch64 / 272512 字节 | ARM / 30180 字节 |
| SHA256 | `656ace25d47cc453685cc4109b5f4578d466b219d759008ac5720244ee899722` | `69948f5005c308166f7de48a0520edde792ad786ed3bf52d6d0d674d6b055a3c` |

这些是实在的成套差异，但不是已确认的失败原因。不能只换 `.so`、ARM32 Hook 或 UA 就宣称修好 Windows。Docker 此次没有换库、UA或算法便完成首轮认证，说明其原有路线在那次现场可用，不证明 Windows ARM64 可用。

重新追踪 bootstrap POST 后，未发现有证据支持的构造错误：两边均先用全零 Algo-ID 作为请求头和 body，发送对应 UA、Accept、body MD5 与 Client-ID。Windows `extraHeaders` 虽用追加方式，但当前 bootstrap 不传额外头，不能把它说成已产生重复 Algo-ID。固定 `portal_node` 仅用于 legacy fallback；动态配置成功后使用实际 ticket URL。

Windows `ZsmHeaderReader` 只提供格式和 UUID 候选，不是算法支持检测。`NATIVE_SESSION_REJECTED` 仅证明 `load()` 返回零，无法独自区分响应不合适、格式/算法不支持或模拟环境。旧原生回归使用 lambda 替身，188 项包内检查不等于真实 JNI 与校园网认证通过。历史证据见[原生失败记录](WINDOWS-AUTH-SESSION-ISSUE.md)和[09-30 审计](WINDOWS-DESIGN-AND-AUTH-AUDIT-2026-09-30.md)。

## 下一步应按阶段推进

优先在 Windows 专属分支处理已复现的 W2-ATTR / W2-AUTH-DUP，并补上安全 XML 分阶段诊断；按 Docker 已验证的规则逐项移植和验证，保留 Windows 的认证通道及拒绝边界。随后通过实际 Windows 新包的现场日志决定 AUTH-INIT 是否仍需原生修复。本轮核查没有实施这些运行代码变更。

| v2.3beta.2 当前日志 | 能够判断的阶段 |
| --- | --- |
| `LOGIN_ATTEMPT` 后 `PORTAL_CONFIG_XML_INVALID` / `PORTAL_AUTH_URL_DUPLICATE`，未出现 `AUTH_ENDPOINTS` | 门户阻断，尚未进入 bootstrap / 原生会话 |
| `AUTH_ENDPOINTS`、`TICKET_RESPONSE` / `TICKET_BODY` 后报 `ZSM_*` | 入口/响应格式校验，不能直接归为 native 算法 |
| `ZSM_METADATA` 后 `NATIVE_SESSION_REJECTED` / `NATIVE_LOAD_EXCEPTION` / `NATIVE_ENVIRONMENT_INIT_FAILED` | 原生加载或模拟环境阶段；按具体码继续对照受控格式/Algo-ID |
| `SESSION_READY`、`TICKET_READY` 后失败 | 会话已建立，继续排查 ticket/login/confirm，不能沿用旧初始化结论 |
| `LOGIN_CONFIRMED` 与 `LOGIN_SUCCESS` | 首次 keep 通过；持续心跳、恢复和长期稳定仍需另验收 |

**Windows 的 `LOGIN_ATTEMPT` 在门户发现之前打印。** 不能直接套用 Docker 日志中该标记的阶段含义。无论恢复多少次，同一不兼容输入仍会失败；连续三次确定性错误后暂停是已有策略，不是算法修复。网络已被 Docker 或其他会话放通时，Windows 可能只探测在线并等待，不能将此当作 Windows 独立认证成功。

本次新日志已补足当前失败阶段；下一步需要补齐 XML 分阶段安全诊断与已复现的兼容规则，再验证是否越过门户以及后续认证结果。后续只收集阶段、固定错误码、响应长度/格式及受控 Algo-ID，不需要账号、密码、完整 URL、票据、密钥或原始 ZSM。当前剩余范围继续在[统一待办](PENDING-OPTIMIZATIONS.md)维护，WOPT-01 不关闭。
